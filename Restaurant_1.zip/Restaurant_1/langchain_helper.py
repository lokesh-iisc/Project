from langchain_groq import ChatGroq
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.chains import SequentialChain
from Secure_Key import graq_key

import os 
os.environ['GRAQ_API_KEY'] =graq_key

llm = ChatGroq(
    model='llama-3.1-70b-versatile',
    temperature=0.6,
    groq_api_key = graq_key)


def generate_resta_name_and_item(cuisine):
    # Chain 1 
    prompt_template_name = PromptTemplate( 
        input_variables = ['cuisine'],
        template = 'I want to open a restaurant for {cuisine} food. Suggest a fency name for this.'
    )
    name_chain = LLMChain(llm=llm, prompt=prompt_template_name, output_key = "restaurant_name")

    # Chain 2
    prompt_template_items = PromptTemplate(
        input_variables = ['restaurant_name'],
        template = "suggest some menu items for {restaurant_name}. Return it as comma separated"
    )
    food_item_chain = LLMChain(llm=llm, prompt=prompt_template_items, output_key = "menu_items")

    chain = SequentialChain(
        chains = [name_chain, food_item_chain],
        input_variables = ['cuisine'],
        output_variables = ['restaurant_name','menu_items']
    )
    response = chain({'cuisine': cuisine})

    return response