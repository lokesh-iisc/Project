import streamlit as st
import langchain_helper
st.title("Restaurant Name Generator")

cuisine = st.sidebar.selectbox("Pick a Cuisine",("Indian","Itelian","Maxican","Japanese","American","Korean"))
# cuisine = st.sidebar.text_input("Enter a Cuisine")

if cuisine:
    response = langchain_helper.generate_resta_name_and_item(cuisine)
    st.header(response['restaurant_name'].strip())
    menu_items = response['menu_items'].strip().split(",")
    st.write("**_Menu_**")

    for item in menu_items:
        st.write('-',item )
