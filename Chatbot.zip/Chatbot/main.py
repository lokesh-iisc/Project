import streamlit as st
import langchain_helper
st.title("General Chatbot")

user_input = st.sidebar.text_input("Hi,Search")
# cuisine = st.sidebar.text_input("Enter a Cuisine")

if user_input:
    response = langchain_helper.generate_response(user_input)
    #st.header(response['restaurant_name'].strip())
    #menu_items = response['menu_items'].strip().split(",")
    st.write(response)

